require 'slack-mathbot/commands/calculate'
require 'slack-mathbot/commands/about'
require 'slack-mathbot/commands/help'
