module SlackMathbot
  ABOUT = <<-ABOUT
    #{SlackMathbot::VERSION}
    https://github.com/dblock/slack-mathbot
    https://twitter.com/dblockdotorg
  ABOUT
end
