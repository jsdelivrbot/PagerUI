module SlackMathbot
  class Bot < SlackRubyBot::Bot
  end
end
