require 'spec_helper'

describe SlackMathbot do
  it 'has a version' do
    expect(SlackMathbot::VERSION).to_not be nil
  end
end
